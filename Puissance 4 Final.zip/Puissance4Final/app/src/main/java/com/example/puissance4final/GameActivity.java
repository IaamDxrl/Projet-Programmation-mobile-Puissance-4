package com.example.puissance4final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {

    private final Button[][] boutons = new Button[6][7];

    private boolean TourJoueur1 = true;
    private int NbRound;
    private int PointJoueur1;
    private int PointJoueur2;
    private TextView textViewJoueur1;
    private TextView textViewJoueur2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        textViewJoueur1 = findViewById(R.id.text_view_p1);
        textViewJoueur2 = findViewById(R.id.text_view_p2);

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                String ButtonID = "button_" + i + j;
                int resID = getResources().getIdentifier(ButtonID, "id", getPackageName());
                boutons[i][j] = findViewById(resID);
                boutons[i][j].setOnClickListener(this);
            }
        }
        Button BoutonReset = findViewById(R.id.bouton_reset);
        BoutonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }

        if (TourJoueur1) {
            ((Button) v).setText("X");
        } else {
            ((Button) v).setText("O");
        }
        NbRound++;


        if (VerifWin()) {
            if (TourJoueur1) {
                Joueur1Gagne();
            } else {
                Joueur2Gagne();
            }

        } else {
            TourJoueur1 = !TourJoueur1;
        }

    }

    private boolean VerifWin() {
        String[][] grille = new String[6][7];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                grille[i][j] = boutons[i][j].getText().toString();
            }
        }
        for (int i = 0; i < 6; i++) {
            if (grille[i][0].equals(grille[i][1])
                    && grille[i][0].equals(grille[i][2])
                    && grille[i][0].equals(grille[i][3])
                    && !grille[i][0].equals("")) {
                return true;
            }
            if (grille[i][1].equals(grille[i][2])
                    && grille[i][1].equals(grille[i][3])
                    && grille[i][1].equals(grille[i][4])
                    && !grille[i][1].equals("")) {
                return true;
            }
            if (grille[i][2].equals(grille[i][3])
                    && grille[i][2].equals(grille[i][4])
                    && grille[i][2].equals(grille[i][5])
                    && !grille[i][2].equals("")) {
                return true;
            }

            if (grille[i][3].equals(grille[i][4])
                    && grille[i][3].equals(grille[i][5])
                    && grille[i][3].equals(grille[i][6])
                    && !grille[i][3].equals("")) {
                return true;
            }
        }
        for (int j = 0; j < 7; j++) {
            if (grille[0][j].equals(grille[1][j])
                    && grille[0][j].equals(grille[2][j])
                    && grille[0][j].equals(grille[3][j])
                    && !grille[0][j].equals("")) {
                return true;
            }
            if (grille[1][j].equals(grille[2][j])
                    && grille[1][j].equals(grille[3][j])
                    && grille[1][j].equals(grille[4][j])
                    && !grille[1][j].equals("")) {
                return true;
            }
            if (grille[2][j].equals(grille[3][j])
                    && grille[2][j].equals(grille[4][j])
                    && grille[2][j].equals(grille[5][j])
                    && !grille[2][j].equals("")) {
                return true;
            }

        }

        if (grille[0][0].equals(grille[1][1])
                && grille[0][0].equals(grille[2][2])
                && grille[0][0].equals(grille[3][3])
                && !grille[0][0].equals("")) {
            return true;
        }
        if (grille[1][1].equals(grille[2][2])
                && grille[1][1].equals(grille[3][3])
                && grille[1][1].equals(grille[4][4])
                && !grille[1][1].equals("")) {
            return true;
        }
        if (grille[2][2].equals(grille[3][3])
                && grille[2][2].equals(grille[4][4])
                && grille[2][2].equals(grille[5][5])
                && !grille[2][2].equals("")) {
            return true;
        }


        if (grille[1][0].equals(grille[2][1])
                && grille[1][0].equals(grille[3][2])
                && grille[1][0].equals(grille[4][3])
                && !grille[1][0].equals("")) {
            return true;
        }
        if (grille[2][1].equals(grille[3][2])
                && grille[2][1].equals(grille[4][3])
                && grille[2][1].equals(grille[5][4])
                && !grille[2][1].equals("")) {
            return true;
        }
        if (grille[2][0].equals(grille[3][1])
                && grille[2][0].equals(grille[4][2])
                && grille[2][0].equals(grille[5][3])
                && !grille[2][0].equals("")) {
            return true;
        }

        if (grille[0][1].equals(grille[1][2])
                && grille[0][1].equals(grille[2][3])
                && grille[0][1].equals(grille[3][4])
                && !grille[0][1].equals("")) {
            return true;
        }
        if (grille[1][2].equals(grille[2][3])
                && grille[1][2].equals(grille[3][4])
                && grille[1][2].equals(grille[4][5])
                && !grille[1][2].equals("")) {
            return true;
        }
        if (grille[2][3].equals(grille[3][4])
                && grille[2][3].equals(grille[4][5])
                && grille[2][3].equals(grille[5][6])
                && !grille[2][3].equals("")) {
            return true;
        }


        if (grille[0][2].equals(grille[1][1])
                && grille[0][2].equals(grille[2][0])
                && !grille[0][2].equals("")) {
            return true;
        }
        return false;
    }

    private void Joueur1Gagne() {
        PointJoueur1++;
        Toast.makeText(this, "Le joueur 1 a gagné!", Toast.LENGTH_SHORT).show();
        MajPointJoueur();
        SupprimGrille();
    }

    private void Joueur2Gagne() {
        PointJoueur2++;
        Toast.makeText(this, "Le joueur 1 a gagné!", Toast.LENGTH_SHORT).show();
        MajPointJoueur();
        SupprimGrille();
    }

    private void MajPointJoueur() {
        textViewJoueur1.setText("Joueur 1: " + PointJoueur1);
        textViewJoueur2.setText("Joueur 2: " + PointJoueur2);
    }

    private void SupprimGrille() {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                boutons[i][j].setText("");
            }
        }
    }
}